==========================
Virtual Jaguar SDL Nspire
==========================
Version 1.1
Port by gameblabla with some upstream backported code.

MAKE SURE YOU ARE RUNNING NDLESS LATEST VERSION
OR ELSE IT WON'T WORK DUE TO STACK ISSUES !

Here's a port of Virtual Jaguar for the TI Nspire CX.
You better overclock your calc if you want to have decent emulation
speed on this thing !
But one could remark anyway this does not matter anyway, as it will run very slowly.

Not all games run properly.
Wolfenstein 3D and Cybermorpth are the fastest game that are emulated.
Bubsy only works with the No-DSP version, same for Worms.
Atari Karts works very slowly, don't even attempt to run it lol.
Raiden, Power Drive Rally... and more don't boot. (or will crash)

ESCAPE = Quit
CTRL = C
SHIFT = B
BACKSPACE = A
TAB = Pause
Enter = Option
Numpad = Jag Numpad


=============
CHANGELOG
=============

Version 1.1
Based on my GCW0 modifications.
Better speed and smaller file size.
